<?php

require_once ROOT_DIR . '/cdnhub/admin/init.php';