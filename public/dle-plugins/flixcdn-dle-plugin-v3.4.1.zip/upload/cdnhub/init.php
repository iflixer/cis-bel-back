<?php

define('CDNHUB_DIR', dirname(__FILE__));

require_once CDNHUB_DIR . '/functions.php';

require_once CDNHUB_DIR . '/classes/CDNHub.php';
$cdnhub = new CDNHub;