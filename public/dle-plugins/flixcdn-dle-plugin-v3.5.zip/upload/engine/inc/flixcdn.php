<?php

require_once ROOT_DIR . '/flixcdn/admin/init.php';