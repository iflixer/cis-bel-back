<?php

return array (
  'seo' =>
  array (
    'on' => 'on',
    'url' => '[title_rus]{title_rus}[/title_rus][year] {year}[/year][custom_translation] {custom_translation}[/custom_translation][custom_quality] {custom_quality}[/custom_quality][serial][season] {season} сезон[/season][episode] {episode} серия[/episode][/serial]',
    'title' => '[title_rus]{title_rus}[/title_rus]',
    'meta' => 
    array (
      'title' => '[title_rus]{title_rus}[/title_rus][year] {year}[/year][translation] {translation}[/translation][quality] {quality}[/quality][serial][format_season] {format_season}[/format_season][format_episode] {format_episode}[/format_episode][/serial]',
      'description' => '[title_rus]{title_rus}[/title_rus][year] {year}[/year][translation] {translation}[/translation][quality] {quality}[/quality][serial][season] {season} сезон[/season][episode] {episode} серия[/episode][/serial]',
    ),
  ),
);